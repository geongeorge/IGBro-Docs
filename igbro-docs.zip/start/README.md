# Getting Started

## Knowing Instant games.

Instant games are the new way of gaming over facebook where the users can find and play games directly in the messenger chats or news feed, on mobile devices and desktops.

### Let's get started.

1.  Head over to [developers.facebook.com](https://developers.facebook.com)
2.  Login to your account. If you don’t have one, Signup !

3.  Now you have account, start creating your app. 

    -   Name it
    -   Fill the details page.
    -   Select Games as the Category
    -   Select **Trivia & Word** as the Sub-Category.
    -   Leave out the privacy policy and terms of service url for now. we'll add them later
    -   Finally, upload the app icon.

4. Now to Turn it into an instant game.
    -   Add **Instant Games** in the **PRODUCTS** section of your app(in the left side bar)
    -   Now fill in the details sub page in the new **Instant Games** in the left side abr
    -   You may use these sample images as a reference for the images: [download samples](https://www.dropbox.com/sh/n4wh7dqcyctmpk7/AAByXfWyy4cjA-G784-6_7H_a?dl=0)
    -   **Web hosting** tab allows you to upload an instant game zip file
    -   After you upload a new version. You click the ⭐ Star button next to a version to **Push the game to production** So you can start playing the game.
