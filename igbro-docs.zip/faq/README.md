# FAQ

Some frequently asked questions related to IGBro and instant games in general.

## Do we need to verify a business for instant games?

Facebook has promised to roll out individual developer verification soon. Untill then you need to add your app to a verified business to get approved. [Read more](https://www.facebook.com/business/help/2058515294227817)

## Do we need to have an Apple developer team id?

Facebook and Apple has made it impossible to get a game reviewed without one. You can get one from your friends. Although I don't recommend: You can also buy this from other sources like fiverr for cheap.

## Do we have a messenger bot?

Currently, we don’t have a bot. But one is in the making and will be released soon. The plans and pricing for that will be announced later.

## Is the license valid for lifetime?
As we’re providing the scripts to every customer, The license will stay valid for as long as we can maintain. And after that we might even release a verification free script for everyone purchased.

## Do you provide installation services?
Although not everytime. You can try to contact us via the live chat/email and see if we provide the service at that time

## Do you provide customization services?
It is best to contact us via email and let us know what you wanna get done. We might do it or might not do it. 
