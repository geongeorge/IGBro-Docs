<!-- docs/_sidebar.md -->

* [Home](/)
* [FAQ](/faq/)
* [Getting Started](/start/)
* [Installation](/install/)
  * [Introduction](/install/?id=introduction)
  * [Admin Panel](/install/?id=admin-panel)
  * [Front End](/install/?id=front-end-installation)
* [Front end Features](/frontend/)
    * [Google Analytics](/frontend/?id=google-analytics)
    * [Set up text and languages](/frontend/?id=set-up-textlanguages-optional)
    * [Adding Deeplinks](/frontend/?id=adding-deeplinks-in-to-specific-quizzes)
* [Monetization](/monetization/)