# IGBro Instant Game


 Thank you 👏 for purchasing IGBro instant game package! The most advanced admin panel script in the planet for instant quiz games.

 ![igbro plans](./images/documentation.jpg)
 
 >The installation steps below is same for any package you have chosen (pro/plus/lite)

## License:

> We have a licensing system setup and anyone who found to involve in fraudulent activities may be instantly banned from the platform.

## Guides:

Although not necessary, reading in order would give you the most out of this tutorial.

* [Home](/)
* [FAQ](/faq/)
* [Getting Started](/start/)
* [Installation](/install/)
  * [Introduction](/install/?id=introduction)
  * [Admin Panel](/install/?id=admin-panel)
  * [Front End](/install/?id=front-end-installation)
* [Front end Features](/frontend/)
    * [Google Analytics](/frontend/?id=google-analytics)
    * [Set up text and languages](/frontend/?id=set-up-textlanguages-optional)
    * [Adding Deeplinks](/frontend/?id=adding-deeplinks-in-to-specific-quizzes)
* [Monetization](/monetization/)

